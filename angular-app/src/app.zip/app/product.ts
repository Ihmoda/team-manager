export class Product {
    name: string;
    price: number;
    url: string;
}
